# Wrapped generics (B1')

Generic, mathematically unambiguous, not sidelink-specific. Wrapped in v1, replaced in v2.

| Module | Replaces |
|---|---|
| `ofdmMod` / `ofdmDemod` | CP handling per numerology |
| `polarDecode` | successive cancellation list |
| `ldpcDecode` | layered min-sum |
| `demodLLR` | LLR computation per modulation order |

## The wrapper contract
Each function has a signature **we** define and a toolbox body. When the C port happens, the
body changes and nothing above it does. Write the signature before the body, and write it as
though the toolbox did not exist — if the signature mentions a toolbox object, it is wrong.

This one rule is the difference between a port and a rewrite.

## Tests
Verified against the normative encoder each one inverts, over the full parameter range. A
decoder that recovers what our encoder produced is doing its job; it does not need to match
anyone else's decoder, because decoding is not normative.

## Gate
Every wrapper round-trips against its normative counterpart across the parameter range, and
`module-auditor` reports zero toolbox calls outside `+lib/` and `+rx/`.
