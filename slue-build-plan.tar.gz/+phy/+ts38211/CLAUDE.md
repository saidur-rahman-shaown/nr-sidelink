# TS 38.211 — physical channels and modulation

Two waves. Wave A is B1 (sequence primitives, needed by everything). Wave B is B3 (sidelink
signals, needs only wave A).

## Wave A — primitives (B1)

| Module | Clause | Notes |
|---|---|---|
| `goldSeq` | §5.2.1 | length-31, Nc = 1600 |
| `mSeq` | cl. 8 | configurable polynomial and initialisation |
| `lowPaprSeq` | §5.2.2 | base sequences for PSFCH |
| `modMap` | §5.1 | π/2-BPSK, QPSK, 16/64/256QAM |
| `scramble` | §5.2.1 | generic; per-channel initialisation lives in `+chan/` |
| `resourceGrid` | cl. 8 | grid object, RE addressing, per antenna port |

`goldSeq` is the first module written in the project. Small, used everywhere, and its header
and test file set the conventions the rest of the codebase copies. Spend the time on it.

## Wave B — sidelink signals (B3)

| Module | Clause | Notes |
|---|---|---|
| `sPss` | cl. 8 | 127 subcarriers, BPSK, **two** candidate m-sequences |
| `sSss` | cl. 8 | 127 subcarriers, BPSK, Gold-derived |
| `psbchDmrs` | cl. 8 | |
| `pscchDmrs` | cl. 8 | |
| `psschDmrs` | cl. 8 | configuration type 1 and 2; time patterns of 2, 3 or 4 symbols |
| `agcSymbol` | cl. 8 | first symbol of the SL slot duplicates the next symbol |
| `guardSymbol` | cl. 8 | last symbol of the SL region, and around PSFCH |

## Interface rules
- `psschDmrs` takes the pattern index as an input. It never derives the pattern, because the
  pattern is signalled in SCI-1A and chosen by the transmitter from the pool-configured set.
- SLSS ID is composed from its two components at the caller, with the legal-range assertion
  at the composition point. Do not spread it across two modules.
- `agcSymbol` operates on the grid after the duplicated symbol is populated. See the slot
  assembly order in `+phy/CLAUDE.md`.
- `scramble` is generic. The per-channel initialisation derivation stays visible at the call
  site in `+chan/`, never hidden in a shared helper.

## Tests
- Property: m-sequence period and balance; Gold cross-correlation bound; constant modulus for
  the sync sequences; constellation power normalisation per modulation order.
- Worked examples via `independent-verifier`: a gold sequence output at a stated
  initialisation; the S-PSS sequence at a stated N_ID2; the S-SSS at a stated SLSS ID; the
  DMRS symbol positions for each configured pattern.
- Structural: DMRS RE positions match the tables; guard symbol is empty; AGC symbol is
  bit-identical to the symbol it duplicates.

## Gate
Wave A: every primitive matches its worked example, property tests pass.
Wave B: every sequence matches its worked example, DMRS positions match for every configured
pattern, AGC duplication is exact.

## Known traps
- The Nc = 1600 offset in the Gold sequence initialisation. Off-by-one here is silent and
  catastrophic later.
- The two candidate m-sequences for S-PSS. Implementing one and assuming the other follows a
  pattern is a common shortcut and it is wrong.
- DMRS pattern availability is pool-configured, so a pattern legal in the spec may be illegal
  in this pool. Assert against the config, not the spec range alone.
